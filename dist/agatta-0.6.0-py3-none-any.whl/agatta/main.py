# -*- coding: utf-8 -*-

"""
    AGATTA: Three-item analysis Python package

Usage:    
    agatta analysis <file> <file> [-s -i -p --rosette=<type> --software=<type> --method=<type> --weighting=<type> --analysis=<str> --nrep=<int> --consensus=<type> --chartest --ri --prefix=<file>]
    agatta tripdec <file> [-s -i -p --prefix=<file>]
    agatta ri <file> <file> [-s -i -j --index=<type> --weighting=<type> --prefix=<file>]
    agatta chartest  <file> <file> [-s -i -j --pdf=<dir>]
    agatta convert <file> [-s -i -v --taxarep=<file> -p=<type> --log --software=<type> --weighting=<type>  --nrep=<int> --analysis=<str> --multiplier=<int> --prefix=<file> --filetype=<type>]
    agatta fp <file> [-s -v -i --method=<type> --prefix=<file>]
    agatta consensus <file> [-s -i --consensus=<type> --prefix=<file>]
    agatta describetree <file> [-s --showtaxanames --prefix=<file>]
    agatta standardisation <file> <file> [-s -v]
    agatta hmatrix <file> [-s -v --chardec --method=<type> --prefix=<file>]
    agatta -h | --help

Options:
    -h --help            show this
    -v                   verbose mode
    -s                   silent mode
    -i                   replace taxa names by id from taxabloc for the first file
    -j                   replace taxa names by id from taxabloc for the second file
    --ri                 launch retention index computation
    -p=<type>            fast tree decomposition using parallelisation (choose auto for automatic detection of the number of cores, or choose a specific number of cores, or choose no if you don't want a parallel analysis) [default: auto]
    --prefix=<file>      prefix of the output file [default: agatta_out]
    --directory=<dir>    directory for output chartest files [default: ./]
    --software=<type>    convert module will compute a file compatible with the software used for the pipeline between paup, tnt and agatta (only branch and bound) [default: tnt]
    --weighting=<type>   specify the type of triplet weighting for the three-item analysis (FW,FWNL,UW,MW,AW,NW) [default: FW]
    --method=<type>      specify the method used to produce subtrees (VR, RZB, No) [default: VR]
    --consensus=<type>   specify which kind of consensus to produce between strict consensus (strict) and reduced cladistic consensus (rcc) (Wilkinson 1994) [default: strict]
    --index=<type>       specify which can of retention index to use (ri, itri, itrisym_sum, itrisym_product) [default: ri]
    --chardec            decompose character trees into components from a cao matrix
    --chartest           launch character states test
    --multiplier=<int>   specifies an integer by which the weight of each column in PAUP/WQFM file is multiplied [default: 1000000]
    --log                add a line to save a log file
    --filetype=<type>    the file to be converted in matrix contains trees or triplets [two options: characters, triplets] [default: characters] 
    --showtaxanames      print the list of terminal taxa in the output file of describetrees
    --analysis=<str>     type of analysis, heuristic, bandb, or auto (bandb if 15 terminals or less) [default: auto]
    --nrep=<int>         number of replicates for an analysis [default: 1000]
    --rosette=<type>     path of the file for taxa conversion


"""

import sys
import os
import time
import docopt
from .ini import character_extraction
from .ini import phylo_to_areagram
from .ini import matrix_to_trees
from .analysis import del_replications_forest
from .analysis import main_tripdec
from .interpret import RI
from .interpret import ITRI
from .interpret import triplet_distance
from .interpret import character_states_test
from .interpret import constrict
from .interpret import rcc
from .interpret import describe_forest
from .out import agatta_analysis
from .out import convert
from .__version__ import __version__


def main():
    # docopt flags parsing
    arguments = docopt.docopt(__doc__, version=__version__)

    def coremain():

        start_time = time.time()

        print("AGATTA {}".center(80).format(__version__))
        print()
        print("Three-item analysis python package".center(80))
        print()
        print("alpha".center(80))

        # Complete analysis
        if arguments["analysis"]:
            agatta_analysis(arguments["<file>"][0],
                            arguments["<file>"][1],
                            arguments["--software"],
                            arguments.get("-i", False),
                            arguments["--method"],
                            arguments["--weighting"],
                            arguments["-p"],
                            arguments["--prefix"],
                            arguments["--analysis"],
                            arguments["--nrep"],
                            arguments.get("--rosette", False),
                            arguments["--chartest"],
                            arguments["--ri"],
                            arguments["--consensus"],
                            arguments.get("--pdf", False),
                            arguments.get("-v", False))

        # triplet decomposition
        elif arguments["tripdec"]:

            main_tripdec(arguments["<file>"][0],
                         arguments["--prefix"],
                         arguments.get("-i", False),
                         arguments["--weighting"],
                         arguments["-p"],
                         arguments.get("-v", False))

        # retention index calculation
        elif arguments["ri"]:

            # retention index
            if arguments["--index"] == "ri":

                RI(character_extraction(arguments["<file>"][0],
                                        arguments.get("-i", False)),
                   character_extraction(arguments["<file>"][1],
                                        arguments.get("-j", False)),
                   arguments["--weighting"],
                   output=arguments["--prefix"]+".txt")

            # inter-tree retention index
            elif arguments["--index"] == "itri":

                ITRI(list(character_extraction(
                    arguments["<file>"][0],
                    arguments.get("-i", False)).keys())[0],
                    list(character_extraction(
                        arguments["<file>"][1],
                        arguments.get("-j", False)).keys())[0],
                    arguments["--prefix"],
                    arguments["--weighting"])

            # triplet distance
            elif (arguments["--index"] == "itrisym_sum" or
                  arguments["--index"] == "itrisym_product"):

                triplet_distance(list(character_extraction(
                                arguments["<file>"][0],
                                arguments.get("-i", False)).keys())[0],
                                list(character_extraction(
                                arguments["<file>"][1],
                                arguments.get("-j", False)).keys())[0],
                                arguments["--prefix"],
                                arguments["--index"],
                                arguments["--weighting"])

        # character states testing procedure
        elif arguments["chartest"]:

            character_states_test(character_extraction(
                                  arguments["<file>"][0],
                                  arguments.get("-i", False)),
                                  character_extraction(
                                      arguments["<file>"][1],
                                      arguments.get("-j", False)),
                                  arguments["--prefix"],
                                  arguments.get("--pdf", False))

        # convert
        elif arguments["convert"]:
            
            convert(arguments["<file>"][0], 
                    arguments["--filetype"],
                    arguments["--prefix"],
                    arguments["-p"],
                    arguments["--weighting"],
                    arguments["--analysis"],
                    arguments.get("-i", False),
                    arguments["--taxarep"],
                    arguments["--nrep"],
                    arguments.get("--log", False), 
                    arguments["--software"],
                    arguments.get("-v", False),
                    arguments["--multiplier"])

        # free-subtree paralogy analysis
        elif arguments["fp"]:

            del_replications_forest(character_extraction(
                             arguments["<file>"][0],
                             arguments.get("-i", False)),
                             method=arguments["--method"],
                             prefix=arguments["--prefix"],
                             verbose=arguments["-v"])

        # consensus
        elif arguments["consensus"]:

            # strict consensus
            if arguments["--consensus"] == "strict":
                constrict(list(character_extraction(
                          arguments["<file>"][0],
                          arguments.get("-i", False)).keys()),
                          arguments["--prefix"])

            # reduced cladistic consensus
            elif arguments["--consensus"] == "rcc":

                rcc(list(character_extraction(
                    arguments["<file>"][0],
                    arguments.get("-i", False)).keys()),
                    arguments["--prefix"])

        # describe trees
        elif arguments["describetree"]:

            describe_forest(character_extraction(arguments["<file>"][0]),
                            arguments["--prefix"],
                            arguments.get("--showtaxanames", False))

        # standardisation
        elif arguments["standardisation"]:

            phylo_to_areagram(arguments["<file>"][0],
                              arguments["<file>"][1],
                              arguments["--prefix"],
                              verbose=arguments.get("-v", False))

        # transform hierarchical matrix into a tree list
        elif arguments["hmatrix"]:

            matrix_to_trees(arguments["<file>"][0],
                            arguments["--prefix"],
                            arguments["--chardec"],
                            arguments["-v"])

        # display elapsed time
        elapsed_time = time.time() - start_time
        time.strftime("%H:%M:%S", time.gmtime(elapsed_time))

    # class silent mode
    class HiddenPrints:
        def __enter__(self):
            self._original_stdout = sys.stdout
            sys.stdout = open(os.devnull, 'w')

        def __exit__(self, exc_type, exc_val, exc_tb):
            sys.stdout.close()
            sys.stdout = self._original_stdout

    # choice silent mode or not
    if arguments["-s"]:
        with HiddenPrints():
            coremain()
    else:
        coremain()
