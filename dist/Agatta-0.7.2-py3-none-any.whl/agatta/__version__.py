#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Nov 23 11:47:22 2020

@author: valentin
"""

__version__ = "0.7.2"